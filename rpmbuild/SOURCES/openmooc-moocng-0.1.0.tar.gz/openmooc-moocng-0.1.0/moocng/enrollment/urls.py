from moocng.enrollment import enrollment_methods

urlpatterns = enrollment_methods.get_urlpatterns()
