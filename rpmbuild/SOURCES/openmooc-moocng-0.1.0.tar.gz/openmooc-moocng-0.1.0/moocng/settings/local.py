# -*- coding: utf-8 -*-

from .common import *

DEBUG = True
TEMPLATE_DEBUG = DEBUG

COMPRESS_ENABLED = False
#COMPRESS_OFFLINE = True

MONGODB_URI = 'mongodb://localhost:27017/moocng2'

#ALLOW_PUBLIC_COURSE_CREATION = True

# URL that handles the media served from MEDIA_ROOT. Make sure to use a
# trailing slash.
# Examples: "http://media.lawrence.com/media/", "http://example.com/media/"
MEDIA_URL = '/media/'

#STATIC_URL = 'http://localhost2:8000/'

#SMTP server
EMAIL_HOST = 'correo.yaco.es'
SERVER_EMAIL = 'correo.yaco.es'
DEFAULT_FROM_EMAIL = 'ablanco@yaco.es'
EMAIL_PORT = 25
EMAIL_HOST_USER = ''
EMAIL_HOST_PASSWORD = ''

COURSES_USING_OLD_TRANSCRIPT = ['Curso-comercio-electronico', 'emprendimiento-e-innovacion-social']

BROKER_URL = 'redis://localhost:6379/0'

MASSIVE_EMAIL_BATCH_SIZE = 2

# Let authenticated users create their own courses
ALLOW_PUBLIC_COURSE_CREATION = False

MATHJAX_ENABLED = True

MOOCNG_THEME = {
    #    'logo': u'',
    #    'subtitle': u'',
    #    'top_banner': u'',
    #    'right_banner1': u'',
    #    'right_banner2': u'',
    #    'bootstrap_css': u'',
    #    'moocng_css': u'',
    #    'cert_banner': u'',
}

AWS_ACCESS_KEY_ID = "AKIAIH24H3B2UHSVGVSQ"
AWS_SECRET_ACCESS_KEY = "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"
AWS_STORAGE_BUCKET_NAME = "openmooc-test"
AWS_S3_UPLOAD_EXPIRE_TIME = (60 * 5)  # 5 minutes

ASSET_SLOT_GRANULARITY = 7

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'filters': {
        'require_debug_false': {
            '()': 'django.utils.log.RequireDebugFalse'
        }
    },
    'handlers': {
        'console': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
        },
        'mail_admins': {
            'level': 'ERROR',
            'filters': ['require_debug_false'],
            'class': 'django.utils.log.AdminEmailHandler'
        }
    },
    'loggers': {
        'django.request': {
            'handlers': ['mail_admins', 'console'],
            'level': 'DEBUG',
            'propagate': True,
        },
        'moocng.videos.download': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': True,
        },
        'moocng.videos.youtube': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': True,
        },
    }
}

CACHES = {
    'default': {
        #'BACKEND': 'django.core.cache.backends.dummy.DummyCache',
        'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
        'LOCATION': '127.0.0.1:11211',
    }
}
